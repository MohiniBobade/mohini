package com.OurFinanceCompany.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.OurFinanceCompany.model.Ledger;

public interface LedgerRepository extends JpaRepository<Ledger, Integer>{

	Ledger findByledgerId(int ledgerId);



}
