package com.OurFinanceCompany.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Documents {

	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private int dId;
	private byte[] adharcard;
	private byte[] pancard;
	private byte[] propertyDetails;
	private byte[] electricbill;
	private byte[] photo;
	private byte[] signature;
	private byte[] guarantorPropertyDoc;
	private byte[] guarantorStamp;
	private byte[] cheque;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Applicant applicant;
}
