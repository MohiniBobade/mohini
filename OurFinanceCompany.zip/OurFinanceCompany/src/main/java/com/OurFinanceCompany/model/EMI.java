package com.OurFinanceCompany.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class EMI {
@Id
@GeneratedValue(strategy =GenerationType.AUTO)
private int emailId;
private long loanamount;
private int tenure;
private double rateOfIntrest;
private long totalamount;
private long intrestamount;
}
