package com.OurFinanceCompany;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.OurFinanceCompany.model.Applicant;


@SpringBootApplication
public class OurFinanceCompanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurFinanceCompanyApplication.class, args);
		
	
		
	}

}
