package com.OurFinanceCompany.IService;

import org.springframework.stereotype.Service;

import com.OurFinanceCompany.model.Cibil;


public interface CibilIService {

	int saveCibil(Cibil cibil);

}
