package com.OurFinanceCompany.IService;

import java.util.List;

import com.OurFinanceCompany.model.Applicant;
import com.OurFinanceCompany.model.Customer;

public interface CustomerIService {

	Customer savedata(Customer c);

	List<Customer> getAll();

	Customer getOneCustomer(int customerId);

	

}
