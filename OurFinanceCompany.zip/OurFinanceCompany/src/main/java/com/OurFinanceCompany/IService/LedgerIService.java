package com.OurFinanceCompany.IService;

import java.util.List;

import com.OurFinanceCompany.model.Ledger;

public interface LedgerIService {

	void save(Ledger ledger);

	List<Ledger> getAllLedger();

	Ledger getOneLedger(int ledgerId);

	Ledger updateLedger(int ledgerId, Ledger l);

	void deletedata(int ledgerId);

}
