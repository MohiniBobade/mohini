package com.OurFinanceCompany.IService;

import java.util.List;

import com.OurFinanceCompany.model.Applicant;
import com.OurFinanceCompany.model.Customer;

public interface ApplicantIService {


	Applicant saveappli(Applicant applicant);


	
	
}
