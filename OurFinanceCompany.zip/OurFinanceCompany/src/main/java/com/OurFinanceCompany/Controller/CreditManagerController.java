package com.OurFinanceCompany.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreditManagerController {

}
