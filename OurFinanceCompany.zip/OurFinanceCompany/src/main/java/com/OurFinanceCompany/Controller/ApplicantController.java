package com.OurFinanceCompany.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OurFinanceCompany.IService.ApplicantIService;
import com.OurFinanceCompany.IService.CustomerIService;
import com.OurFinanceCompany.model.Applicant;
import com.OurFinanceCompany.model.Customer;

@RestController
public class ApplicantController {
	@Autowired
	CustomerIService custoIS;
	
	@Autowired
	ApplicantIService appliIS;
	
	@PostMapping("/saveApplicant/{customerId}")
	public Applicant saveApplicant(@RequestBody Applicant applicant, @PathVariable int customerId) {
		Customer c1=custoIS.getOneCustomer(customerId);
		applicant.setCustomer(c1);
		Applicant app=appliIS.saveappli(applicant);
		return app;
		
	}

}
