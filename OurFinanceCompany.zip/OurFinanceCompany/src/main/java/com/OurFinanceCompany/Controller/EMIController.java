package com.OurFinanceCompany.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OurFinanceCompany.model.EMI;

@RestController
public class EMIController {
	
	
	
//	@PostMapping("/saveEMI")
//	public int saveEMI(@RequestBody EMI emi) {
//		int TotalLoanAmount=emi.g
//		
//		return 0;
//		
//	}

}
