package com.OurFinanceCompany.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OurFinanceCompany.IService.CibilIService;
import com.OurFinanceCompany.model.Cibil;

@RestController
public class CibilController {
	@Autowired
	CibilIService cibilIS;
	
	@PostMapping("/saveCibil")
	public int cibilscore(@RequestBody Cibil cibil) {
		
		int c=cibilIS.saveCibil(cibil);
		return c;
		
	}

}
