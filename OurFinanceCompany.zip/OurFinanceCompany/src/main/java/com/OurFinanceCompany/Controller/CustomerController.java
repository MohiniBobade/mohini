package com.OurFinanceCompany.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OurFinanceCompany.IService.CustomerIService;
import com.OurFinanceCompany.model.Customer;


@RestController
public class CustomerController {
	@Autowired
	CustomerIService cIService;
	
	
	@PostMapping("/saveCustomer")
	public Customer savedata(@RequestBody Customer c) {
		
		return cIService.savedata(c);
		
	}
	
	@GetMapping("/getCustomer")
	public List<Customer> getData() {
		List<Customer> list=cIService.getAll();
		return list;
		
	}
	
	@GetMapping("getData/{customerId}")
	public Customer getCustomer(@PathVariable int customerId) {
		Customer c=cIService.getOneCustomer(customerId);
		return c;
		
	}
	

}
