package com.OurFinanceCompany.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OurFinanceCompany.IService.LedgerIService;
import com.OurFinanceCompany.Repository.LedgerRepository;
import com.OurFinanceCompany.model.Ledger;
@Service
public class LedgerServiceIMPL implements LedgerIService {
	
	@Autowired
	LedgerRepository ledgerRepo;

	@Override
	public void save(Ledger ledger) {
		ledgerRepo.save(ledger);
		
	}

	@Override
	public List<Ledger> getAllLedger() {
		return ledgerRepo.findAll();
	}

	@Override
	public Ledger getOneLedger(int ledgerId) {
		return ledgerRepo.findByledgerId(ledgerId);
	}

	@Override
	public Ledger updateLedger(int ledgerId, Ledger l) {
		Optional<Ledger> l1=ledgerRepo.findById(ledgerId);
		Ledger l2=l1.get();
		l2.setCustomerName(l.getCustomerName());
		l2.setLedgerCreationDate(l.getLedgerCreationDate());
		l2.setTotalLoanAmount(l.getTotalLoanAmount());
		l2.setPayableAmountWithIntrest(l.getPayableAmountWithIntrest());
		l2.setTenureInYear(l.getTenureInYear());
		l2.setMonthlyEMI(l.getMonthlyEMI());
		l2.setAmountPaidTillDate(l.getAmountPaidTillDate());
		l2.setRemainingAmount(l.getRemainingAmount());
		l2.setDefaulterCount(l.getDefaulterCount());
		l2.setPreviousEmiStatus(l.getPreviousEmiStatus());
		l2.setCurrentMonthEmiStatus(l.getCurrentMonthEmiStatus());
		l2.setLoanEndDate(l.getLoanEndDate());
		l2.setLoanStatus(l.getLoanStatus());
		return ledgerRepo.save(l2) ;
	}

	@Override
	public void deletedata(int ledgerId) {
		ledgerRepo.deleteById(ledgerId);
	}

	
	

}
