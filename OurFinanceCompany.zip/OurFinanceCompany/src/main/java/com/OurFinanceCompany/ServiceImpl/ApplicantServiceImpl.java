package com.OurFinanceCompany.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OurFinanceCompany.IService.ApplicantIService;
import com.OurFinanceCompany.Repository.ApplicantRepository;
import com.OurFinanceCompany.model.Applicant;
import com.OurFinanceCompany.model.Customer;
@Service
public class ApplicantServiceImpl implements ApplicantIService{
	@Autowired
	ApplicantRepository appliRepo;

	

	@Override
	public Applicant saveappli(Applicant applicant) {
		return appliRepo.save(applicant);
	}

	

}


