package com.OurFinanceCompany.ServiceImpl;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OurFinanceCompany.IService.CibilIService;
import com.OurFinanceCompany.Repository.CibilRepository;
import com.OurFinanceCompany.model.Cibil;



@Service
public class CibilServiceImpl implements CibilIService {
	@Autowired
	CibilRepository cibilRep;
	int no;

	@Override
	public int saveCibil(Cibil cibil) {
		Random r=new Random();
		
		
		for(int i=0;i<3;i++) {
			int no= r.nextInt(999);
			cibil.setCibilScore(no);
			
			if(cibil.getCibilScore()>700){
				cibil.setCibilStatus(1);
				cibil.setCibilRemark("Eligible");
				
			}
			else {
				cibil.setCibilStatus(0);
				cibil.setCibilRemark("Not Eligible");
			}
		}
		cibilRep.save(cibil);
		return no;
	}

}
