package com.OurFinanceCompany.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.OurFinanceCompany.IService.CustomerIService;
import com.OurFinanceCompany.Repository.CustomerRepository;
import com.OurFinanceCompany.model.Customer;
@Service
public class CustomerServiceImpl implements CustomerIService{
	@Autowired
	CustomerRepository cRepository;

	@Override
	public Customer savedata(Customer c) {
		return cRepository.save(c);
	}

	@Override
	public List<Customer> getAll() {
		return cRepository.findAll();
	}

	

	@Override
	public Customer getOneCustomer(int customerId) {
		return cRepository.findBycustomerId(customerId);
	}

	
	
}
